<?php
// Connexion à la base de données MySQL
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "limos";

$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Vérifier si un ID d'administrateur est passé dans la requête GET
if (isset($_GET['id']) && !empty($_GET['id'])) {
    // Utiliser une requête SQL pour supprimer l'administrateur
    $sql = "DELETE FROM evenement WHERE id = " . $_GET['id'];

    if ($conn->query($sql) === TRUE) {
        
        echo"<script>alert('Evenement supprimé avec succès.'); window.location.href = 'event.php'; </script>";
        
    } else {
        echo "Erreur lors de la suppression de l'administrateur: " . $conn->error;
    }
} else {
    echo "ID de l'evenement non spécifié.";
    
}

// Fermer la connexion à la base de données
$conn->close();
?>
