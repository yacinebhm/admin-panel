<?php
// Démarre la session
session_start();

// Unset des variables de session
$_SESSION = array();

// Détruire la session
session_destroy();

// Rediriger vers la page de login ou une autre page après la déconnexion
header("Location: login.php");
exit;
?>
