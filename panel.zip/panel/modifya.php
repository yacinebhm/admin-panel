<?php
// Vérifier si l'ID est présent dans l'URL
if (isset($_GET['id'])) {
    // Récupérer l'ID de l'administrateur à modifier
    $id = $_GET['id'];

    // Vérifier si le formulaire a été soumis
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Récupérer les nouvelles valeurs des champs du formulaire
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $mail = $_POST['mail'];
        $pass = $_POST['pass'];

        // Connexion à la base de données MySQL
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "limos";

        $conn = new mysqli($servername, $username, $password, $dbname);

        // Vérifier la connexion
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Préparer la requête SQL pour mettre à jour les données dans la table
        $sql = "UPDATE admin SET fn='$fname', sn='$lname', mail='$mail', pass='$pass' WHERE id='$id'";

        // Exécuter la requête SQL
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Admin modifier avec succès.'); window.location.href = 'admin.php';</script>";

        
        } else {
            echo "Error updating admin: " . $conn->error;
        }

        // Fermer la connexion à la base de données
        $conn->close();
    } else {
        // Afficher le formulaire avec les informations de l'administrateur à modifier
        // Connexion à la base de données MySQL
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "limos";

        $conn = new mysqli($servername, $username, $password, $dbname);

        // Vérifier la connexion
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Requête SQL pour récupérer les données de l'administrateur
        $sql = "SELECT * FROM admin WHERE id='$id'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Afficher le formulaire pré-rempli avec les informations de l'administrateur
            while ($row = $result->fetch_assoc()) {
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style1.css">
    <title>Modify Admin</title>
</head>

<body>
    <div class="container">
        <form method="post">
            <div class="box">
                <div class="header">
                    <header><img src="assets\images\limos.jpg" alt=""></header>
                    <p>Modify Limose Admin</p>
                </div>
                <div class="input-box">
                    <label for="fname">First Name</label>
                    <input type="text" name="fname" value="<?php echo $row['fn']; ?>">
                </div>
                <div class="input-box">
                    <label for="lname">Last Name</label>
                    <input type="text" name="lname" value="<?php echo $row['sn']; ?>">
                </div>
                <div class="input-box">
                    <label for="mail">E-Mail</label>
                    <input type="email" name="mail" value="<?php echo $row['mail']; ?>">
                    <i class="bx bx-envelope"></i>
                </div>
                <div class="input-box">
                    <label for="pass">Password</label>
                    <input type="password" name="pass" value="<?php echo $row['pass']; ?>">
                    <i class="bx bx-lock"></i>
                </div>
                <input type="submit" name="update_user" value="UPDATE">
            </div>
        </form>
    </div>
</body>

</html>
<?php
            }
        } else {
            echo "Admin not found";
        }

        // Fermer la connexion à la base de données
        $conn->close();
    }
} else {
    echo "Admin ID not provided";
}
?>
